<?php
 echo $_REQUEST['editor1'];


?>