<!DOCTYPE html>
<!--
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
-->
<html>
<head>
	<title>Replace Textareas by Class Name &mdash; CKEditor Sample</title>
	<meta charset="utf-8">
	<script src="ckeditor/ckeditor.js"></script>
	<link rel="stylesheet" href="ckeditor/sample.css">
</head>
<body>
	<form action="index2.php" method="post">
		<p>
			<textarea class="ckeditor" cols="80" id="editor1" name="editor1" rows="10">Ayaz
            </textarea>
		</p>
		<p>
			<input type="submit" value="Submit">
		</p>
	</form>
</body>
</html>
<?php
echo "CK Editor Integration";
/*$content_fulltext = "HELLO WORD";
include("ckeditor/fckeditor.php") ;
$sBasePath = 'ckeditor/';
$oFCKeditor2 = new FCKeditor('edit_static_content_main_text') ;
$oFCKeditor2->BasePath		= $sBasePath ;
$oFCKeditor2->Width			= '90%' ;
$oFCKeditor2->Height			= '550' ;
$oFCKeditor2->ToolbarSet	= 'FullAll' ;
$oFCKeditor2->Value			= $content_fulltext;
$oFCKeditor2->Create() ;
*/?>




