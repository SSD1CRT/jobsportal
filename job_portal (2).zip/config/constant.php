<?php
    // return [
    //     'Host' => 'smtp.googlemail.com',
    //     'Username' => 'parnamiapp2020@gmail.com',
    //     'Password' => 'Parnami@2020',
    //     'SMTPSecure' => 'ssl',
    //     'Port' => 465,
    //     'mail_from_address' => 'parnamiapp2020@gmail.com',
    //     'mail_from_name' => 'Purefresh'
    // ];

    return [
        'Host' => 'smtp.googlemail.com',
        'Username' => 'order@agarbattishop.com',
        // 'Username' => 'jamesanderson4494@gmail.com',
        'Password' => 'Parnami#77',
        // 'Password' => 'iwant$100',
        'SMTPSecure' => 'ssl',
        'Port' => 465,
        'mail_from_address' => 'order@mjdmart.com',
        'mail_from_name' => 'Purefresh',
        'merchant_id' => 270178,

        'working_key' => 'E551AF41E32FC7DC0F195AB522ED9887',
        'access_code' => 'AVZP03HH37CC11PZCC',
        'url_for_payment' => 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction',
            
        'online_working_key' => '0AF846D77330046B62A7423FF4021191',
        'online_access_code' => 'AVBQ94HH56CC78QBCC',
        'online_url_for_payment' => 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction',

        'PAYTM_MID' => 'kESLbX31956769361827',
        'PAYTM_MERCHANT_KEY' => 'dSCeLQHXBlqA_3KE',
        'PAYTM_WEBSITE' => 'WEBSTAGING',
        'PAYTM_ENVIRONMENT' => 'https://securegw-stage.paytm.in',
            
        'online_PAYTM_MID' => 'uhBcTq76094735012490',
        'online_PAYTM_MERCHANT_KEY' => 'AMbb#QUu!g7dm2zS',
        'online_PAYTM_WEBSITE' => 'DEFAULT',
        'online_PAYTM_ENVIRONMENT' => 'https://securegw.paytm.in',
    ];
?>