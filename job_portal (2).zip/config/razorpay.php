<?php
return [
	'razor_key' => 'rzp_test_KNebULXXJ3DVBy',
	'razor_secret' => '7jstiuAAZ84e4JhEKUPX8rGb'
];